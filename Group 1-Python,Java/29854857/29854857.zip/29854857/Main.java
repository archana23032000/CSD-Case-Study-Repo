import java.util.Date;

public class Main {
    public static void main(String[] args) {
        EmployeeManager manager = new EmployeeManager();

        manager.getDepartments().put(1, new Department(1, "HR"));
        manager.getDepartments().put(2, new Department(2, "IT"));

        manager.getEmployees().put(1, new Employee(1, "John Doe", "Manager", 50000, "HR", new Date(119, 0, 1)));
        manager.getEmployees().put(2, new Employee(2, "Jane Smith", "Developer", 60000, "IT", new Date(120, 0, 1)));
        manager.getEmployees().put(3, new Employee(3, "Jim Brown", "Analyst", 40000, "IT", new Date(118, 0, 1)));

        System.out.println("Total Salary Expenditure: " + manager.calculateTotalSalaryExpenditure());
        manager.findHighestAndLowestSalary();
        manager.calculateAverageSalaryByDepartment();
        manager.calculateEmployeeTenure();
    }
}
