import java.util.Date; // Importing Date class to handle date-related operations.

public class Employee {
    private int id; // Unique identifier for the employee.
    private String name; // Name of the employee.
    private String designation; // Job title of the employee.
    private double salary; // Salary of the employee.
    private String department; // Department where the employee works.
    private Date joiningDate; // Date when the employee joined the company.

    // Constructor to initialize all attributes of the employee.
    public Employee(int id, String name, String designation, double salary, String department, Date joiningDate) {
        this.id = id;
        this.name = name;
        this.designation = designation;
        this.salary = salary;
        this.department = department;
        this.joiningDate = joiningDate;
    }

    // Getter and setter methods for each attribute.
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public Date getJoiningDate() {
        return joiningDate;
    }

    public void setJoiningDate(Date joiningDate) {
        this.joiningDate = joiningDate;
    }

    // Overriding the toString method to provide a string representation of the employee.
    @Override
    public String toString() {
        return "Employee{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", designation='" + designation + '\'' +
                ", salary=" + salary +
                ", department='" + department + '\'' +
                ", joiningDate=" + joiningDate +
                '}';
    }
}
