import java.util.*;
import java.util.stream.Collectors;

public class EmployeeManager {
    private HashMap<Integer, Employee> employees = new HashMap<>();
    private HashMap<Integer, Department> departments = new HashMap<>();

    public double calculateTotalSalaryExpenditure() {
        return employees.values().stream().mapToDouble(Employee::getSalary).sum();
    }

    public void findHighestAndLowestSalary() {
        Employee highestSalaryEmployee = employees.values().stream()
                .max(Comparator.comparing(Employee::getSalary)).orElse(null);
        Employee lowestSalaryEmployee = employees.values().stream()
                .min(Comparator.comparing(Employee::getSalary)).orElse(null);

        System.out.println("Highest Salary Employee: " + 
            (highestSalaryEmployee != null ? highestSalaryEmployee.toString() : "Not available"));
        System.out.println("Lowest Salary Employee: " + 
            (lowestSalaryEmployee != null ? lowestSalaryEmployee.toString() : "Not available"));
    }

    public void calculateAverageSalaryByDepartment() {
        Map<String, Double> averageSalaryByDept = employees.values().stream()
                .collect(Collectors.groupingBy(Employee::getDepartment, Collectors.averagingDouble(Employee::getSalary)));
        
        averageSalaryByDept.forEach((dept, avgSalary) -> {
            System.out.println("Department: " + dept + ", Average Salary: " + avgSalary);
        });
    }

    public void calculateEmployeeTenure() {
        Date currentDate = new Date();
        employees.values().forEach(employee -> {
            long tenureInMillis = currentDate.getTime() - employee.getJoiningDate().getTime();
            long tenureInDays = tenureInMillis / (1000 * 60 * 60 * 24);
            System.out.println("Employee: " + employee.getName() + ", Tenure: " + tenureInDays + " days");
            
            if (tenureInDays > (365 * 5)) {
                System.out.println("Eligible for Long Service Award: " + employee.getName());
            }
        });
    }

    public HashMap<Integer, Employee> getEmployees() {
        return employees;
    }

    public HashMap<Integer, Department> getDepartments() {
        return departments;
    }
}
